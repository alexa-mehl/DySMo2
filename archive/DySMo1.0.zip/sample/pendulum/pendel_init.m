L=2
m=1
g=9.81
start_dphi=-2
start_phi=90*pi/180
D=0